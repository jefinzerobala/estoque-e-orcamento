package br.com.jeferson.orcamento.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "lancamento")
public class lancamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private LocalDate datalancamento;

    @ManyToOne
    @JoinColumn(name = "idcliente")
    private cliente cliente;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        lancamento that = (lancamento) o;
        return id == that.id && cliente == that.cliente;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LocalDate getDatalancamento() {
        return datalancamento;
    }

    public void setDatalancamento(LocalDate datalancamento) {
        this.datalancamento = datalancamento;
    }

    public br.com.jeferson.orcamento.model.cliente getCliente() {
        return cliente;
    }

    public void setCliente(br.com.jeferson.orcamento.model.cliente cliente) {
        this.cliente = cliente;
    }

    public String getTipolancamento() {
        return tipolancamento;
    }

    public void setTipolancamento(String tipolancamento) {
        this.tipolancamento = tipolancamento;
    }

    public BigDecimal getValorlancamento() {
        return valorlancamento;
    }

    public void setValorlancamento(BigDecimal valorlancamento) {
        this.valorlancamento = valorlancamento;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, cliente);
    }

    private String tipolancamento;
    private BigDecimal valorlancamento;
}
