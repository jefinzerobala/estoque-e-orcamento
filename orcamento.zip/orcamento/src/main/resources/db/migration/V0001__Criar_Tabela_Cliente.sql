create table cliente (
    id bigint not null primary key auto_increment,
    bairro varchar(100),
    celular varchar(100),
    endereco varchar(100),
    nome varchar(100),
    numero varchar(100),
    telefone varchar(100),
    id_municipio int
);

alter table cliente add constraint fk_cliente_id_municipio foreign key id_municipio references municipio (id);

