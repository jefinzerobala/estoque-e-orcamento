create table lancamento(
    id bigint not null primary key auto_increment,
    datalancamento date,
    tipolancamento varchar(100),
    valorlancamento decimal,
    idcliente bigint
);
