create table lancamento(
    id bigint not null primary key auto_increment,
    datalancamento date,
    tipolancamento varchar(100),
    valorlancamento decimal,
    idcliente bigint
);

alter table lancamento add constraint fk_lancamento_idcliente foreign key idcliente references cliente (id);