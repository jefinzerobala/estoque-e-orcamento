create table municipio (
    id int not null primary key auto_increment,
    estado varchar(100),
    nome varchar(100)
);


alter table cliente add constraint fk_cliente_id_municipio foreign key (id_municipio) references municipio (id);


alter table lancamento add constraint fk_lancamento_idcliente foreign key (idcliente) references cliente (id);