create table municipio (
    id int not null primary key auto_increment,
    estado varchar(100),
    nome varchar(100)
);

