create table categoria (
    id int not null primary key auto_increment,
    nome varchar(100)
);



