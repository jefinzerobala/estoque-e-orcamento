create table produto (
    preco decimal,
    id bigint not null primary key auto_increment,
    nomeproduto varchar(100),
    categoria_id int
);

alter table produto add constraint fk_produto_categoria_id foreign key categoria_id references categoria (id);